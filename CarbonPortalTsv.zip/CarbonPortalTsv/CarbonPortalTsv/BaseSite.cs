﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarbonPortalTsv
{
    public class BaseSite
    {
        public int Id { get; set; }
        public string SiteCode { get; set; }
    }
}
