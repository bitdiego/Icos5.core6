﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarbonPortalTsv
{
    class Brand
    {
        public Brand()
        {
            Sensors = new List<Sensor>();
        }

        public int Id { get; set; }
        
        public string Name { get; set; } //mapped to Brand in sql table
        
        public string WebSite { get; set; }

        public List<Sensor> Sensors { get; set; }
    }
}
