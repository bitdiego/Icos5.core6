﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace CarbonPortalTsv
{
    class Configuration
    {
        private static readonly string configFile = @"F:\Diego\CarbonPortalTsv\ICOSInstrumentsmasterlist.tsv";
        private static List<BaseSite> sitesList;
        public static string CONN_STRING = "Data Source=NEW-GAIA\\NEWGAIASQL;Initial Catalog=ICOS;Integrated Security=True;Connect Timeout=300; MultipleActiveResultSets=True";
        public static readonly string meteoSensHeader = "ID_STATION\tVARIABLE\tID_SENSOR\tNSDIST\tEWDIST\tHEIGHT\tSTART_DATE";
        public static readonly string path = @"E:\sa\icosapi\icosapi\cpmetadata\";

        public static List<BaseSite> GetSitesList()
        {
            sitesList = new List<BaseSite>();
            StreamReader cfgSite = new StreamReader(@"F:\Diego\CarbonPortalTsv\sites.txt");
            cfgSite.ReadLine();
            while (!cfgSite.EndOfStream)
            {
                string line = cfgSite.ReadLine();
                if (!String.IsNullOrEmpty(line))
                {
                    string[] record = line.Split(',');
                    sitesList.Add(new BaseSite
                    {
                        Id = int.Parse(record[0]),
                        SiteCode = record[1]
                    });
                }
            }
            cfgSite.Close();
            return sitesList;
        }

        public static string GetLabelDate(string site, SqlConnection cn)
        {
            string labelDate = "";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = @"SELECT [Site],[LabelDate]  FROM [ICOS].[dbo].[ICOSLabellingDate] where Site=@st";
            SqlParameter sitePar = new SqlParameter("st", (string)site);
            cmd.Parameters.Add(sitePar);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();
                labelDate = rd["LabelDate"].ToString();
            }
            rd.Close();
            return labelDate;

        }

        public static void ReadConfigFile()
        {

            //string CONN_STRING = "Data Source=NEW-GAIA\\NEWGAIASQL;Initial Catalog=ICOS;Integrated Security=True;Connect Timeout=300; MultipleActiveResultSets=True";
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = CONN_STRING;
            connection.Open();

            string log = @"F:\Diego\CarbonPortalTsv\logger_"+DateTime.Now.ToString("yyyyMMddHHmm")+".txt";
            StreamWriter wr = new StreamWriter(log);

            /*StreamReader reader = new StreamReader(configFile);
            reader.ReadLine();
            string header = reader.ReadLine();
            while (!reader.EndOfStream)
            {
                //check if brand in Brands Table
                //if not, insert in Brands table; then check modelName if in SensorList table. If sensor is to be inserted, generate new GUID
                //if yes, check modelName if in SensorList table. If sensor is to be inserted, generate new GUID
                string[] line = reader.ReadLine().Split('\t');
                if (line.Length < 5) continue;
                string brand = line[0];
                string modelExp = line[1];
                string modelName = line[2];
                string description = line[3];
                string standardName = line[4];
                CheckBrand(brand, wr, connection);
                if (CheckInstrument(modelName, connection) == 0)
                {
                    Sensor sensor = new Sensor();
                    sensor.Model = modelExp;
                    sensor.InstModel = modelName;
                    sensor.Description = description;
                    sensor.BrandId = GetBrandId(brand, connection);
                    Insertsensor(sensor, wr, connection);
                    InsertInStandardname(modelName, standardName, wr, connection);
                }
            }
            reader.Close();*/
            SensorSnListStat(wr, connection);


            wr.Close();
            connection.Close();
        }

        private static void InsertInStandardname(string modelName, string standardName, StreamWriter wr, SqlConnection connection)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT [IcosName],[StandardName] FROM [ICOS].[dbo].[InstrumentIcosToStandard] where IcosName='" + modelName + "'";
            //SELECT [IcosName],[StandardName] FROM [ICOS].[dbo].[InstrumentIcosToStandard]
            SqlDataReader rd = cmd.ExecuteReader();
            if (!rd.HasRows)
            {
                wr.WriteLine("Not found item {0}, going to insert in InstrumentIcosToStandard table", modelName);
                SqlCommand insertCommand = new SqlCommand();
                insertCommand.Connection = connection;
                insertCommand.CommandText = @"INSERT INTO [ICOS].[dbo].[InstrumentIcosToStandard]  ([IcosName],[StandardName])  VALUES  ('" + modelName + "'   ,'" + standardName + "')";
                try
                {
                    int res = insertCommand.ExecuteNonQuery();
                    wr.WriteLine("++++++ Item {0} {1} correctly saved into InstrumentIcosToStandard table", modelName, standardName);
                }
                catch (Exception e)
                {
                    wr.WriteLine("Error: {0}", e.ToString());
                }
            }
        }

        private static void CheckBrand(string brand, StreamWriter wr, SqlConnection connection)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT  Id ,[Brand] FROM [ICOS].[dbo].[Brands] where Brand='" + brand + "'";
            SqlDataReader rd = cmd.ExecuteReader();
            if (!rd.HasRows)
            {
                Console.WriteLine("Not found brand {0}, going to insert in Brands table", brand);
                wr.WriteLine("Not found id for brand {0}, going to insert in Brands table", brand);
                // wr.WriteLine("\n\nNot found id for brand " + brand);
                SqlCommand insertCommand = new SqlCommand();
                insertCommand.Connection = connection;
                insertCommand.CommandText = @"INSERT INTO [ICOS].[dbo].[Brands]  ([Brand] ,[WebSite])  VALUES  ('" + brand + "'   ,NULL)";
                try
                {
                    int res = insertCommand.ExecuteNonQuery();
                    wr.WriteLine("++++++ Brand {0} correctly saved Brands table", brand);
                }
                catch (Exception e)
                {
                    wr.WriteLine("Error: {0}", e.ToString());
                }
  
            }
            else
            {
                Console.WriteLine("Brand {0} already stored Brands table", brand);
                wr.WriteLine("Brand {0} already stored Brands table", brand);
            }
            rd.Close();

        }

        private static int GetBrandId(string brand, SqlConnection connection)
        {
            int brandId = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT  Id ,[Brand] FROM [ICOS].[dbo].[Brands] where Brand='" + brand + "'";
            SqlDataReader rd = cmd.ExecuteReader();
            if (!rd.HasRows)
            {
               
            }
            else
            {
                rd.Read();
                brandId = int.Parse(rd["Id"].ToString());
            }
            rd.Close();
            return brandId;
        }

        private static int CheckInstrument(string instModel, SqlConnection connection)
        {
            int ctx = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT  * FROM [ICOS].[dbo].[SensorsList] where [InstModel]='" + instModel + "'";
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                ctx = 1;
            }
            
            rd.Close();
            return ctx;
        }

        private static void Insertsensor(Sensor sensor, StreamWriter wr,  SqlConnection connection)
        {
            SqlCommand insertCommand = new SqlCommand();
            insertCommand.Connection = connection;
            insertCommand.CommandText = @"INSERT INTO [ICOS].[dbo].[SensorsList]  ([BrandId]  ,[Model]  ,[InstModel]  ,[Description]   ,[UniqueId])  VALUES
                                           (" + sensor.BrandId + ",'" + sensor.Model + "','" + sensor.InstModel + "','" + sensor.Description + "',NEWID())";
            try
            {
                int res = insertCommand.ExecuteNonQuery();
                wr.WriteLine("++++++ Instrument {0} correctly saved in SensorsList table", sensor.InstModel);
            }
            catch (Exception e)
            {
                wr.WriteLine("----------------Error: {0}", e.ToString());
            }

        }

        private static void SensorSnListStat(StreamWriter wr, SqlConnection connection)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"select distinct qual0 as MODEL, qual1 as SN,  UniqueId 
from DataStorage,[SensorsList] where groupID=2000 
and dataStatus=0 and qual3='purchase' and InstModel=qual0 and siteID not in (70,78, 10, 26, 32, 87, 59)
order by UniqueId";
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string model = rd["MODEL"].ToString();
                string sn = rd["SN"].ToString();
                string uid = rd["UniqueId"].ToString();
                SqlCommand innerCmd = new SqlCommand();
                innerCmd.Connection = connection;
                innerCmd.CommandText = @"SELECT * FROM Sensors_Sn_List where ModelId='" + uid + "' and SerialNumber='" + sn + "'";
                SqlDataReader innerRd = innerCmd.ExecuteReader();
                if (!innerRd.HasRows)
                {
                    wr.WriteLine("xxx> Sensor with UID {0} Model {1} and SN {2} not present in Sensors_Sn_List table  <xxxx", uid, model, sn);
                    Console.WriteLine("xxxx------- Sensor with UID {0} Model {1} and SN {2} not present in Sensors_Sn_List table  ----------xxxxxx", uid, model, sn);
                    SqlCommand insertCommand = new SqlCommand();
                    insertCommand.Connection = connection;
                    insertCommand.CommandText = @"INSERT INTO [ICOS].[dbo].[Sensors_Sn_List] ([ModelId],[SerialNumber],[SensorId]) 
VALUES ('"+uid+"','"+sn+"',NEWID())";
                    try
                    {
                        int res = insertCommand.ExecuteNonQuery();
                        wr.WriteLine("++++++ SensorSn {0} {1} {2} correctly saved in Sensors_Sn_List table", model, sn, uid);
                    }
                    catch (Exception e)
                    {
                        wr.WriteLine("----------------Error: {0}", e.ToString());
                    }
                }

            }

            rd.Close();
        }

        public static DateTime isoDate2DT(string isoDate)
        {
            int year = int.Parse(isoDate.Substring(0, 4));
            int month = 0;
            int day = 0;
            int hh = 0;
            int mm = 0;
            int sec = 0;
            if (isoDate.Length == 4)
            {
                return (new DateTime(year));
            }
            if (isoDate.Length > 4)
            {
                month = int.Parse(isoDate.Substring(4, 2));
            }
            if (isoDate.Length > 6)
            {
                day = int.Parse(isoDate.Substring(6, 2));
            }
            else
            {
                day = 1;
            }
            if (isoDate.Length > 8)
            {
                hh = int.Parse(isoDate.Substring(8, 2));
            }
            if (isoDate.Length > 10)
            {
                mm = int.Parse(isoDate.Substring(10, 2));
            }
            if (isoDate.Length > 12)
            {
                sec = int.Parse(isoDate.Substring(12, 2));
            }
            return (new DateTime(year, month, day, hh, mm, sec));
        }

    }
}
