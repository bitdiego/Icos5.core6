﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.IO;

namespace CarbonPortalTsv
{
    class CpFileWriter
    {
        public static void WriteMeteoSensFile(string pathToFile, List<BaseSite> sites)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = Configuration.CONN_STRING;
            cn.Open();
            //get all sites to be processed
            //they come from ICOSSubmittingStations.csv??? ask....
            StringBuilder sb = new StringBuilder();

            foreach (var site in sites)
            {
                Console.WriteLine("Processsing site {0}", site.SiteCode);

                string labelDate = Configuration.GetLabelDate(site.SiteCode, cn);
                if (String.IsNullOrEmpty(labelDate))
                {
                    //raise error!!!
                    continue;
                }
                List<Instrument> instList = GetBMInstList(cn, labelDate, site.Id);
                foreach (var sensor in instList)
                {
                    string query = @"select id_datastorage, siteID,qual0 as [BM_MODEL],qual1 as [BM_SN],qual2 as [BM_TYPE],qual3 as [BM_VARIABLE_H_V_R],
qual4 as [BM_HEIGHT],qual5 as [BM_EASTWARD_DIST],qual6 as [BM_NORTHWARD_DIST],qual13 as [BM_DATE],
Model, InstModel,UniqueId,ModelId,SensorId,
site_code from DataStorage,ICOS_site, SensorsList, Sensors_Sn_List 
where id_icos_site=siteID AND groupID=2005 AND siteID=$SID$ and datastatus = 0
and (qual3 like 'SWC%')
and qual2 in('installation','variable map')
and qual0=InstModel
and qual0='" + sensor.Model + "' and qual1='" + sensor.SerialNumber + "' and qual3='" + sensor.VariableVHR + "' and ModelId=UniqueId and SerialNumber=qual1 order by BM_VARIABLE_H_V_R, BM_DATE, BM_MODEL,BM_SN";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = cn;
                    cmd.CommandText = query.Replace("$SID$", site.Id.ToString());

                    SqlDataReader reader = cmd.ExecuteReader();
                    string preNorth = "", preEast = "", preHei = "", preModel = "", preSn = "", preVar = "";
                    while (reader.Read())
                    {
                        string model = reader["BM_MODEL"].ToString();
                        string sn = reader["BM_SN"].ToString();
                        string date = reader["BM_DATE"].ToString();
                        string _variable = reader["BM_VARIABLE_H_V_R"].ToString();
                        string _op = reader["BM_TYPE"].ToString().ToLower();
                        string north = reader["BM_NORTHWARD_DIST"].ToString();
                        string east = reader["BM_EASTWARD_DIST"].ToString();
                        string height = reader["BM_HEIGHT"].ToString();
                        string sc = reader["site_code"].ToString();
                        string _renamedVar = getRenamedVar(_variable, reader["site_code"].ToString(), reader["BM_DATE"].ToString(), cn);
                        if (String.IsNullOrEmpty(_renamedVar))
                        {
                            continue;
                        }
                        if (String.Compare(_op, "variable map", true) == 0)
                        {
                            if (String.IsNullOrEmpty(north) || String.IsNullOrEmpty(east) || String.IsNullOrEmpty(height))
                            {
                                //find north, east, height by sensor installation
                                FindPosition(model, sn, date, ref north, ref east, ref height, site.Id, cn);

                                // 
                            }
                        }
                        /*else
                        {
                            preNorth = north;
                            preEast = east;
                            preHei = height;
                        }
                         * 
                         * */

                        if (String.Compare(north, preNorth) == 0 && String.Compare(east, preEast) == 0 && String.Compare(height, preHei) == 0
                            && String.Compare(model, preModel, true) == 0 && String.Compare(sn, preSn, true) == 0 && String.Compare(_variable, preVar, true) == 0)
                        {
                            continue;
                        }
                        else
                        {
                            preNorth = north;
                            preEast = east;
                            preHei = height;
                            preModel = model;
                            preSn = sn;
                            preVar = _variable;
                        }
                        double xNorth = Convert.ToDouble(north);
                        double xEast = Convert.ToDouble(east);
                        double xHei = Convert.ToDouble(height);
                        xNorth = Math.Round(xNorth, 2, MidpointRounding.AwayFromZero);
                        xEast = Math.Round(xEast, 2, MidpointRounding.AwayFromZero);
                        xHei = Math.Round(xHei, 2, MidpointRounding.AwayFromZero);
                        sb.Append(reader["siteID"].ToString() + "\t" +
                                  _renamedVar + "\t" +
                                  reader["SensorId"].ToString() + "\t" +
                                  xNorth.ToString() + "\t" +
                                  xEast.ToString() + "\t" +
                                  xHei.ToString() + "\t" +
                                  date);
                        sb.Append("\r\n");
                    }
                    reader.Close();
                }
                instList.Clear();
                Console.WriteLine("Site {0} OK.....", site.SiteCode);
            }
            cn.Close();
            WriteFile(pathToFile, Configuration.meteoSensHeader, sb.ToString());
            sb.Clear();
        }

        private static void WriteFile(string path, string header, string content)
        {
            StreamWriter wr = new StreamWriter(path, false);
            wr.WriteLine(header);
            wr.Write(content);
            wr.Close();
        }


        private static void FindPosition(string model, string sn, string date, ref string north, ref string east, ref string height, int siteId, SqlConnection cn)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = @"select top 1 qual0 as [BM_MODEL],qual1 as [BM_SN],qual2 as [BM_TYPE],qual3 as [BM_VARIABLE_H_V_R],
qual4 as [BM_HEIGHT],qual5 as [BM_EASTWARD_DIST],qual6 as [BM_NORTHWARD_DIST],
qual13 as [BM_DATE],site_code from DataStorage,ICOS_site where id_icos_site=siteID AND groupID=2005 and datastatus = 0
AND siteID=" + siteId + " and qual0='" + model + "' and qual1='" + sn + "' and qual2 in ('installation') and qual13<='" + date + "'  order by qual13 desc";
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            north = reader["BM_NORTHWARD_DIST"].ToString();
            east = reader["BM_EASTWARD_DIST"].ToString();
            height = reader["BM_HEIGHT"].ToString();
            reader.Close();
        }

        private static List<Instrument> GetBMInstList(SqlConnection cn, string labelDate, int siteId)
        {
            List<Instrument> sensors = new List<Instrument>();
            SqlCommand mainCmd = new SqlCommand();
            mainCmd.Connection = cn;
            mainCmd.CommandText = @"select qual0 as [BM_MODEL],qual1 as [BM_SN],qual2 as [BM_TYPE],qual3 as [BM_VARIABLE_H_V_R],
qual13 as [BM_DATE],site_code from DataStorage,ICOS_site where id_icos_site=siteID AND groupID=2005 AND siteID=@siteId 
and datastatus =0
and qual3 like 'SWC%'
and qual2 in ('installation','variable map')
 order by qual3, qual0, qual1, qual13";
            SqlParameter sitePar = new SqlParameter("siteId", (int)siteId);
            mainCmd.Parameters.Add(sitePar);

            string _preModel = "";
            string _preSn = "";
            SqlDataReader reader = mainCmd.ExecuteReader();
            while (reader.Read())
            {
                string model = reader["BM_MODEL"].ToString();
                string sn = reader["BM_SN"].ToString();
                string varHVR = reader["BM_VARIABLE_H_V_R"].ToString();
                string date = reader["BM_DATE"].ToString();
                if (model != _preModel || sn != _preSn)
                {
                    if (_preModel == "" && _preSn == "")
                    {
                        sensors.Add(new Instrument
                        {
                            Model = model,
                            SerialNumber = sn,
                            VariableVHR = varHVR,
                            Date = date
                        });
                        _preModel = model;
                        _preSn = sn;
                        continue;
                    }
                    else
                    {
                        //check if (_preModel, _preSn) is still installed
                        // Console.WriteLine("Model, Sn, Date {0} {1} {2}", _preModel, _preSn, date);
                        // wr.WriteLine("*******Testing Model, Sn, Date {0} {1} {2}", _preModel, _preSn, date);
                        SqlCommand xcmd = new SqlCommand();
                        xcmd.Connection = cn;
                        xcmd.CommandText = @"select top 1 qual0 as [BM_MODEL],qual1 as [BM_SN],qual2 as [BM_TYPE],qual3 as [BM_VARIABLE_H_V_R],
qual13 as [BM_DATE],site_code from DataStorage,ICOS_site where id_icos_site=siteID AND groupID=2005 AND siteID=" + siteId + " and datastatus =0  and (qual0 = '" + model + "' and qual1='" + sn + "' ) and qual13>='" + labelDate + "' and qual2 in ('installation','removal')  order by qual13";
                        SqlDataReader xrd = xcmd.ExecuteReader();
                        if (!xrd.HasRows)
                        {
                            // wr.WriteLine("+++++The fucking Model, Sn, Date {0} {1} never installed after labeldate", _preModel, _preSn);
                            //if (!sensors.Any(x => x.Model == _preModel && x.SerialNumber == _preSn && x.VariableVHR == varHVR ))
                            if (!sensors.Any(x => x.Model == model && x.SerialNumber == sn && x.VariableVHR == varHVR))
                            {
                                sensors.Add(new Instrument
                                {
                                    Model = model,// _preModel,
                                    SerialNumber = sn,// _preSn,
                                    VariableVHR = varHVR,
                                    Date = date
                                });
                                _preModel = model;
                                _preSn = sn;
                            }
                        }
                        else
                        {

                            xrd.Read();
                            string _op = xrd["BM_TYPE"].ToString();
                            string _dt = xrd["BM_DATE"].ToString();
                            string _vHVR = xrd["BM_VARIABLE_H_V_R"].ToString();
                            if (String.Compare(_op, "removal", true) == 0)
                            {
                                //find first installation date before labeldate

                                SqlCommand preLabelCmd = new SqlCommand();
                                preLabelCmd.Connection = cn;
                                preLabelCmd.CommandText = @"select top 1 qual0 as [BM_MODEL],qual1 as [BM_SN],qual2 as [BM_TYPE],qual3 as [BM_VARIABLE_H_V_R],
qual13 as [BM_DATE],site_code from DataStorage,ICOS_site where id_icos_site=siteID AND groupID=2005 AND siteID=" + siteId + " and datastatus =0  and (qual0 = '" + model + "' and qual1='" + sn + "' ) and qual13<'" + labelDate + "' and qual2 in ('installation')  order by qual13 desc";
                                SqlDataReader preLabelRd = preLabelCmd.ExecuteReader();
                                if (!preLabelRd.HasRows)
                                {
                                    //raise error!!!
                                    throw new Exception();
                                }
                                else
                                {
                                    preLabelRd.Read();
                                    _dt = preLabelRd["BM_DATE"].ToString();
                                    _vHVR = preLabelRd["BM_VARIABLE_H_V_R"].ToString();
                                    if (!sensors.Any(x => x.Model == model && x.SerialNumber == sn && x.VariableVHR == _vHVR))
                                    {
                                        sensors.Add(new Instrument
                                        {
                                            Model = model,
                                            SerialNumber = sn,
                                            VariableVHR = _vHVR,
                                            Date = _dt
                                        });
                                        _preModel = model;
                                        _preSn = sn;
                                    }
                                    // wr.WriteLine("---->Model, Sn, Changed Date {0} {1} {2}", _preModel, _preSn, _dt);
                                }
                                preLabelRd.Close();
                            }
                            else
                            {
                                //insert into sensor list
                                //   wr.WriteLine("+++++The fucking Model, Sn, Date {0} {1} installed on {2}", _preModel, _preSn, _dt);
                                if (!sensors.Any(x => x.Model == model && x.SerialNumber == sn && x.VariableVHR == _vHVR))
                                {
                                    sensors.Add(new Instrument
                                    {
                                        Model = model,
                                        SerialNumber = sn,
                                        VariableVHR = _vHVR,
                                        Date = _dt
                                    });
                                    _preModel = model;
                                    _preSn = sn;
                                }
                            }
                        }

                        xrd.Close();
                        //wr.WriteLine("************************************");
                        _preModel = model;
                        _preSn = sn;
                    }
                }
            }/**/
            mainCmd.Parameters.Clear();
            reader.Close();
            //sensors = sensors.OrderBy(s => s.SerialNumber).ToList();
            return sensors;
        }

        private static string getRenamedVar(string _variable, string siteCode, string date, SqlConnection cn)
        {
            string renamedVar = "";
            SqlCommand command = new SqlCommand();
            command.Connection = cn;
            DateTime _dt = Configuration.isoDate2DT(date);
            command.CommandText = @"select TOP 1 new_name from Var_Renamed where site='" + siteCode + "' and original_name='" + _variable + "' and date_start<='" + _dt.ToString("yyyy-MM-dd HH:mm:ss") + "'";
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                renamedVar = reader["new_name"].ToString();
            }
            else
            {
                reader.Close();
                command.CommandText = @"select TOP 1 new_name from Var_Renamed where site='" + siteCode + "' and original_name='" + _variable + "' and date_start>'" + _dt.ToString("yyyy-MM-dd HH:mm:ss") + "'";
                reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    renamedVar = reader["new_name"].ToString();
                }
            }
            reader.Close();
            return renamedVar;
        }
    }
}
