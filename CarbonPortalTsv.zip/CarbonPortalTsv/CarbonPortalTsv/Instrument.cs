﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarbonPortalTsv
{
    public class Instrument
    {
        public string Model { get; set; }
        public string SerialNumber { get; set; }
        public string Type { get; set; }
        public string VariableVHR { get; set; }
        public double Height { get; set; }
        public double EastwardDist { get; set; }
        public double NorthwardDist { get; set; }
        public double SamplingInt { get; set; }
        public string InstHeat { get; set; }
        public string InstShielding { get; set; }
        public string InstAspiration { get; set; }
        public int LoggerID { get; set; }
        public int FileID { get; set; }
        public string Date { get; set; }
        public string DateStart { get; set; }
        public string DateEnd { get; set; }
        public int DateUnc { get; set; }
        public string Comment { get; set; }
    }
}
