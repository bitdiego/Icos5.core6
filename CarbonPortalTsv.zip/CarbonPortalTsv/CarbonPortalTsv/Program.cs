﻿using System;//
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.SqlClient;

namespace CarbonPortalTsv
{
    class Program
    {
        static void Main(string[] args)
        {
            var cList = Configuration.GetSitesList();
            
            CpFileWriter.WriteMeteoSensFile(Configuration.path + "METEOSENS.tsv", cList);


            //Configuration.ReadConfigFile();

           /* string CONN_STRING = "Data Source=NEW-GAIA\\NEWGAIASQL;Initial Catalog=ICOS;Integrated Security=True;Connect Timeout=300; MultipleActiveResultSets=True";
            string file = @"F:\Diego\CarbonPortalTsv\cplist.txt";
            string log = @"F:\Diego\CarbonPortalTsv\logger.txt";
            string ErrStr = "";
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = CONN_STRING;
            connection.Open();
            StreamWriter wr = new StreamWriter(log);
            StreamReader reader = new StreamReader(file);
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] contents = line.Split('\t');
                string brand = contents[0];
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT  Id ,[Brand] FROM [ICOS].[dbo].[Brands] where Brand='" + contents[0] + "'";
                SqlDataReader rd = cmd.ExecuteReader();
                if (!rd.HasRows)
                {
                    Console.WriteLine("Not found id for brand "  + brand);
                    wr.WriteLine("\n\nNot found id for brand " + brand);
                    rd.Close();
                    continue;
                }
                else
                {
                    try
                    {
                        rd.Read();
                        int brandId = int.Parse(rd["Id"].ToString());
                        string model = contents[1];
                        string instModel = contents[2];
                        string desc = contents[3];
                        rd.Close();
                        ErrStr = cmd.CommandText = @"INSERT INTO [ICOS].[dbo].[SensorsList]([BrandId],[Model],[InstModel],[Description])    
    VALUES(" + brandId + ",'" + model + "','"+instModel+"','"+desc+"')";
                    
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception e)
                    {
                        wr.WriteLine("\n\nError in record insert::\n" + ErrStr);
                        continue;
                    }
                }
                //rd.Close();
            }

            reader.Close();
            wr.Close();
            connection.Close();*/
        }
    }
}
