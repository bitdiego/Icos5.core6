﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarbonPortalTsv
{
    class Sensor
    {
        public int Id { get; set; }
        
        public int BrandId { get; set; }
        
        public string Model { get; set; }
       
        public string InstModel { get; set; }

        public string InstStandardName { get; set; }
        
        public string Description { get; set; }
        
        public string UniqueId { get; set; }

    }
}
