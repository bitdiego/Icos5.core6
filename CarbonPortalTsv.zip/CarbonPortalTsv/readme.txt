Brand	Model	INST_MODEL (LIST)	Description	INST BADM STANDARD	ATC ID
---------------------------------------------------------------------------------------
[0]->Brand
[1]->instrument model explained
[2]->instrument model in BADMList
[3]->description
[4]->inst standard name

Skip 1st line
2nd lin: header
